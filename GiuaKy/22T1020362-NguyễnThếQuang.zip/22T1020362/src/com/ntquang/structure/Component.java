package com.ntquang.structure;

public interface Component {
	public double getDungLuong();
	public String getDuongDan();
}
